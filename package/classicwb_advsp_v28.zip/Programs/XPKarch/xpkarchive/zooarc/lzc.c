#ifndef LINT
static char sccsid[]="@(#) lzc.c 2.6 88/01/30 18:39:15";
#endif /* LINT */

/*
Lempel-Ziv compression.  Mostly based on Tom Pfau's assembly language
code.

The contents of this file are hereby released to the public domain.

                -- Rahul Dhesi  1986/12/31
*/

/*

Adapted from "zoo" written by Rahul Dhesi

-- Matthias Meixner

*/

#include <stdio.h>
#include <stdlib.h>
#include "zooarc.h"

/* zoomem.h defines IN_BUF_SIZE & OUT_BUF_SIZE */
#include "zoomem.h"

/* lzconst.h contains constants for lzd() and lzc() */
#include "lzconst.h"

void init_ctab(void);
void wr_ccode(int);
int rd_cch(void);
int lukup_ccode(int, int, int *);
void ad_ccode(int, int, int);
void check_ratio(void);
void flush_c(int);

/* interval at which to check ratio */
#define CHECKGAP 4000
#define NEXT_USE  1
#define FIRST_USE 2
#define FOUND 0

struct    tabentry {
   int first;
   int next;
   char z_ch;
};

extern char *out_buf_adr;
extern char *in_buf_adr;

static char memflag=0;         /* memory allocated? */
struct tabentry *table;       /* this table also used by lzd.c */

static unsigned int free_code;
static int nbits;
static unsigned int max_code;
static unsigned int bitsout;
static int bit_interval;
static unsigned int bytesin, ratio, ratflag;
static unsigned int in_offset, in_size;
static unsigned int bit_offset;

char *in_f;
long size;

void free_lzc(void)
{
   if(table) free(table);
   table=memflag=0;
}

int lzc (struct XarSubIO *xio)
{
   int nextch, prefix_code, k;
   int where;
   int status;

   in_f = xio->IOMem;
   size=xio->Size;

   bit_offset = in_offset = in_size = 0;

   if (memflag == 0) {
      table = (struct tabentry *) malloc((MAXMAX+10) * sizeof(struct tabentry));
      if(!table) Error(XARERR_NO_MEMORY);
      memflag++;
   }

   init_ctab();
   wr_ccode(CLEAR);
   nextch = rd_cch();
   if (nextch == EOF) {                  /* note real EOF, not Z_EOF */
      wr_ccode (Z_EOF);
      flush_c ((int) ((bit_offset + 7) / 8));
      return (0);                         /* normal return from compress */
   }

   /* compression loop begins here with nextch holding the next input char */
   loop1:
   if (ratflag != 0)
   check_ratio();
   nextch &= 0xff;          /* turn character to code */
   loop2:
   prefix_code = nextch;
   nextch = rd_cch();
   if (nextch == EOF) {                  /* note real EOF, not Z_EOF */
      wr_ccode (prefix_code);
      wr_ccode (Z_EOF);
      flush_c ((int) ((bit_offset + 7) / 8));
      return (0);                         /* normal return from compress */
   }
   nextch &= 0xff;           /* force to 8 bits */

   k = nextch;
   status = lukup_ccode (prefix_code, nextch, &where);
   if (status == FOUND) {
      nextch = where;           /* where found */
      goto loop2;
   }

   /* reach here with status = FIRST_USE or NEXT_USE */
   ad_ccode (status, nextch, where);

   wr_ccode (prefix_code);
   nextch = k;

   if (free_code <= max_code)
   goto loop1;
   if (nbits >= MAXBITS) {
      /* To continue using table after it is full, remove next two lines */
      wr_ccode (CLEAR);
      init_ctab();

      goto loop1;
   }

   nbits++;
   max_code = max_code << 1;
   goto loop1;
} /* end lzc() */

void wr_ccode (int code)
{
   unsigned int ofs_inbyte, hibits;
   int byte_offset;

   bitsout += nbits;          /* total number of bits written */
   bit_interval -= nbits;
   if (bit_interval < 0)
   ratflag = 1;          /* time to check ratio */

   byte_offset = bit_offset / 8;
   ofs_inbyte = bit_offset % 8;     /* offset within byte */
   bit_offset += nbits;        /* allowing for new code */

   if (byte_offset >= OUTBUFSIZ - 4) {
      flush_c (byte_offset);
      bit_offset = ofs_inbyte + nbits;
      out_buf_adr[0] = out_buf_adr [byte_offset];
      byte_offset = 0;
   }

   code = code & 0xffff;       /* force to 16 bits */

   if (ofs_inbyte == 0)
   out_buf_adr[byte_offset]   = code & 0xff;
   else
   out_buf_adr[byte_offset] |= (code << ofs_inbyte) & 0xff;

   hibits = ((unsigned int) code) >> (8 - ofs_inbyte);
   out_buf_adr[byte_offset+1] = hibits & 0xff;
   out_buf_adr[byte_offset+2] = (((unsigned int) hibits) >> 8) & 0xff;

} /* end wr_ccode() */

void init_ctab(void)
{
   int i;
   bytesin = bitsout = ratio = ratflag = 0;
   bit_interval = CHECKGAP;
   nbits = 9;
   max_code = 512;
   for (i = 0; i < MAXMAX+1; i++) {
      table[i].z_ch = table[i].first = table[i].next = -1;
   }
   free_code = FIRST_FREE;
} /* end init_ctab() */


int rd_cch(void)
{
   int count;
   bytesin++;
   if (in_offset == in_size) {

      count=size>INBUFSIZ?INBUFSIZ:size;
      memcpy(in_buf_adr,in_f,count);
      in_f+=count;
      size-=count;

      if (count == 0) {
         return (EOF);              /* real EOF, not Z_EOF */
      }

      in_size = count;
      in_offset = 0;
   }
   in_offset++;
   return (in_buf_adr[in_offset-1] & 0xff);
} /* end rd_cch () */

void check_ratio()
{
   bit_interval = CHECKGAP;
   bitsout = 0;
   bytesin = 0;
} /* end check_ratio() */


void ad_ccode (int status,int ch,int index)
{
   if (status == NEXT_USE)
   table[index].next = (free_code >= MAXMAX ? -1 : free_code);
   else       /* else must be FIRST_USE */
   table[index].first = (free_code >= MAXMAX ? -1 : free_code);

   if (free_code <= MAXMAX) {
      table[free_code].first = table[free_code].next = -1;
      table[free_code].z_ch = ch & 0xff;
      free_code++;
   }
} /* end ad_ccode() */

int lukup_ccode (int index,int ch,int * where)
{
   *where = index;
   index = table[index].first;
   if (index == -1) {
      return (FIRST_USE);           /* not found, first use */
   } else {
      while (1) {
         if ((table[index].z_ch & 0xff) == (ch & 0xff)) {
            *where = index;
            return (FOUND);
         }
         *where = index;
         index = table[index].next;
         if (index == -1) {
            return (NEXT_USE);
         }
      } /* end while */
   } /* end else */
} /* end lukup_ccode() */

void flush_c (int count)
{
   if (count != 0) {
      fwrite(out_buf_adr,count,1,arcfile);
      if (ferror(arcfile)) Error(XARERR_WRITE_ERROR);
   }
}
