
/*
**   $Filename: xpkarchive.h $
**   $Release: 2.0 $
**
**
**
**   (C) Copyright 1993,1994,1995 Matthias Meixner
**       All Rights Reserved
*/

#ifndef LIBRARIES_XAR_H
#define LIBRARIES_XAR_H

#include <libraries/xpk.h>
#include <proto/exec.h>
#include <exec/types.h>
#include <exec/lists.h>
#include <exec/memory.h>
#include <proto/dos.h>
#include <dos/dos.h>

#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include <libraries/dos.h>
#include <libraries/dosextens.h>

#define SYS_AMIGA        ('A'<<8|'M')
#define SYS_ATARI_ST     ('S'<<8|'T')
#define SYS_ARCHIMEDES   ('A'<<8|'R')
#define SYS_MS_DOS       ('M'<<8|'S')
#define SYS_UNIX         ('U'<<8|'X')
#define SYS_MACINTOSH    ('M'<<8|'A')
#define SYS_HELIOS       ('H'<<8|'E')


#ifdef XPKARCHIVE_OBSOLETE

struct Time {
   UBYTE Year,Month,Day;
   UBYTE Hour,Min,Sec;
};

struct FileData {
   UBYTE CHKSum;           /* FileData-Checksum */
   UBYTE Method,Version;   /* Method=1 , Version=XpkBase->lib_Version  */
   UBYTE Generation;       /* Generation of the file                   */
   USHORT SysID;           /* SystemID : SYS_AMIGA                     */
   ULONG Filesize;         /* original Filesize                        */
   struct Time Time;       /* Date of the file                         */
   USHORT CRC;             /* Checksum of the file (optional)          */
   ULONG Protection;       /* Protectionbits                           */
};

#else

struct XarTime {
   UBYTE Year,Month,Day;
   UBYTE Hour,Min,Sec;
};

struct XarFileData {
   UBYTE CHKSum;           /* FileData-Checksum, for internal use only */
   UBYTE Flags;            /* XARFF_...                                */
   USHORT Generation;      /* Generation of the file                   */
   USHORT SysID;           /* SystemID : SYS_AMIGA                     */
   ULONG Filesize;         /* original Filesize                        */
   struct XarTime Time;    /* Date of the file                         */
   USHORT CRC;             /* Checksum of the file (optional)          */
   ULONG Protection;       /* Protectionbits                           */

   ULONG ValidMask;        /* Every set bit defines a valid Entry      */
                           /* XAR_Valid...                             */
   ULONG CompressedSize;   /* Size of the compressed data              */
   ULONG CRC32;            /* CRC32 value (optional)                   */

   UBYTE Type;             /* XAR_TypeFile | XAR_TypeDir               */
   UBYTE Pad;              /* Padding                                  */

};

/* File-Flags : */

#define XARFF_Deleted (1<<7)

#define XarIsDeletedFD(fdata) ((fdata)->Flags & XARFF_Deleted)
#define XarIsDeleted(lock) XarIsDeletedFD(XarGetFileData(lock))

#endif

/*
 * always valid are:
 *
 *     Flags,Filesize, ValidMask, CompressedSize, Type
 *
 */

#define XAR_ValidGeneration 1
#define XAR_ValidSysID      2
#define XAR_ValidTime       4
#define XAR_ValidCRC        8
#define XAR_ValidProtect   16
#define XAR_ValidCRC32     32


#define XAR_TypeFile 0
#define XAR_TypeDir  1


/************************* structs for version 2.0+ ********************/

struct XarArchiverEntry {
   UBYTE Packer[9];
   UBYTE Type;
};

#define XARTYPE_XPK        0
#define XARTYPE_ARCHIVER   1


struct XarArchiverInfo {

   UBYTE  Name[24];          /* Brief name of the packer, 20 char max   */
   UBYTE  LongName[32];      /* Full name of the packer   30 char max   */
   UBYTE  Description[80];   /* Short packer desc., 70 char max         */

   UBYTE  ArchiveType[24];   /* Archive-type e.g.: lha, zoo, ...        */
   UBYTE  ID[9];             /* ID the packer goes by (XAR format)      */
   UWORD  DefaultMode;       /* default packmode                        */

   UBYTE  Extension[6];      /* proposed extension for the archive-file */
                             /* without '.'                             */
   LONG   Flags;             /* flags for supported input/output        */
                             /* capabilities  (XARIF_...)               */
};

struct XarType {
   UBYTE  ArchiveType[24];   /* Archive-type e.g.: lha, zoo, ...        */
   UBYTE  DefaultID[9];      /* ID the packer goes by (XAR format)      */
   UWORD  DefaultMode;       /* default packmode                        */
};



/* for XarGetPackMode() : */

struct XarPackMode {
   UBYTE ID[9];           /* ID of the packer (-> compression method)      */
   UBYTE Description[10]; /* Description of the compression mode (!= method)*/
   SHORT Mode;            /* Mode to select the packmode, the file was     */
                          /* with. Or -1, if unknown (or for directories)  */
};                        /* Note, that this may be different from the     */
                          /* one, that was given for packing, it is just   */
                          /* within the same range of packmodes            */
                          /* e.g. if the packmethod has two modes with the */
                          /* ranges 0..49 and 50..100 and you packed the   */
                          /* file with mode 69, then 'Mode' may have any   */
                          /* value within 50..100                          */


#define XARIF_PK_MEM     0x00000001 /* Sub library supplies memory packing */
#define XARIF_PK_STREAM  0x00000002 /* Sub library supplies stream packing */
#define XARIF_PK_HOOK    0x00000004 /* Sub library supplies hook packing   */
#define XARIF_UP_MEM     0x00000008 /* Sublib supplies memory unpacking    */
#define XARIF_UP_STREAM  0x00000010 /* Sublib supplies stream unpacking    */
#define XARIF_UP_HOOK    0x00000020 /* Sub library supplies hook unpacking */

#define XARIF_CHECKING   0x00000400 /* Sublib does its own data checking   */

#define XARIF_ENCRYPTION 0x00002000 /* Sub library supports encryption     */
#define XARIF_NEEDPASSWD 0x00004000 /* Sub library requires encryption     */
#define XARIF_MODES      0x00008000 /* Sub library has different modes     */
#define XARIF_LOSSY      0x00010000 /* Sub library does lossy compression  */

#define XARIF_USES_GENERATIONS 0x80000000 /* Sub library supports generations */

#define XAR_NULL_XPKID   0x20202020   /* 4 spaces */

/*************************** end  ************************************/


#ifndef LIBRARIES_XAR_PRIVATE_H

typedef void XarHandle;
typedef void XarLock;

#endif /* LIBRARIES_XAR_PRIVATE_H */

#ifndef TAG_DONE
#define TAG_DONE   (0L)     /* terminates array of TagItems. ti_Data unused */
#define TAG_IGNORE (1L)     /* ignore this item, not end of array           */
#define TAG_USER   (1L<<31) /* differentiates user tags from system tags    */
#endif

#define XAR_TagBase (TAG_USER + 'A'*256 + 'R')
#define ATAG(a)     (XAR_TagBase+(a))

#define XAR_FileName           ATAG(1)
#define XAR_FileNote           ATAG(2)
#define XAR_TimeDay            ATAG(3)
#define XAR_TimeMonth          ATAG(4)
#define XAR_TimeYear           ATAG(5)
#define XAR_TimeHour           ATAG(6)
#define XAR_TimeMin            ATAG(7)
#define XAR_TimeSec            ATAG(8)
#define XAR_DateStamp          ATAG(9)
#define XAR_CRC                ATAG(10)
#define XAR_Protection         ATAG(11)
#define XAR_Generation         ATAG(12)
#define XAR_Error              ATAG(13)
#define XAR_ArcLock            ATAG(14)
#define XAR_Archive            ATAG(15)
#define XAR_DestArchive        ATAG(16)
#define XAR_ArchiveMode        ATAG(17)
#define XAR_NewGeneration      ATAG(18)
#define XAR_FileIndex          ATAG(19)
#define XAR_NewName            ATAG(20)
#define XAR_CurrentTime        ATAG(21)
#define XAR_AutoNextGen        ATAG(22)
#define XAR_ArchiveName        ATAG(23)

/******************* Tags for version 2.0+ *************************/

#define XAR_CRC32              ATAG(24)
#define XAR_ValidMask          ATAG(25)

#define XAR_ArchiversQuery     ATAG(26)
#define XAR_ArraySize          ATAG(27)

#define XAR_ArchiverQuery      ATAG(28)
#define XAR_ModeQuery          ATAG(29)
#define XAR_ProgressHook       XPK_ChunkHook
#define XAR_ShowDirs           ATAG(30)

/*******************************************************************/

#define XAR_ModeOldArchive     0
#define XAR_ModeNewArchive     1
#define XAR_ModeAppend         2

#define XAR_InFH              XPK_InFH
#define XAR_InName            XPK_InName
#define XAR_InBuf             XPK_InBuf
#define XAR_InHook            XPK_InHook
#define XAR_InLen             XPK_InLen
#define XAR_OutFH             XPK_OutFH
#define XAR_OutName           XPK_OutName
#define XAR_OutBuf            XPK_OutBuf
#define XAR_OutHook           XPK_OutHook

#define XAR_PackMethod        XPK_PackMethod
#define XAR_PackMode          XPK_PackMode

#ifdef XPKARCHIVE_OBSOLETE
#define XAR_FileDeleted 255
#else
#define XAR_FileNewest      0
#endif

#define XAR_OutBufLen         XPK_OutBufLen
#define XAR_GetOutLen         XPK_GetOutLen
#define XAR_GetOutBuf         XPK_GetOutBuf
#define XAR_GetOutBufLen      XPK_GetOutBufLen
#define XAR_OutMemType        XPK_OutMemType
#define XAR_Password          XPK_Password


#define XARERR_NO_ERROR                0L

/* Informational */
#define XARINF_NEW_ARCHIVE             1L   /* new archive was created  */
#define XARINF_NOT_EXCLUSIVE           2L
#define XARINF_ARCHIVE_CORRUPT         3L

#define XARMAXINF (3L) /* Note: this define will change with future versions */

/* Warnings */
#define XARWARNING_LEVEL       (1L<<8)
#define XARWARN_DUPLICATE_ARCTYPE      (XARWARNING_LEVEL+1L) /* duplicate archive-type   */
#define XARWARN_DUPLICATE_FILEDATA     (XARWARNING_LEVEL+2L) /* duplicate filedata-chunk */
#define XARWARN_DUPLICATE_FILENOTE     (XARWARNING_LEVEL+3L) /* duplicate filenote-chunk */
#define XARWARN_INVALID_FILENOTE       (XARWARNING_LEVEL+4L) /* invalid filenote         */
#define XARWARN_BODY_WITHOUT_FILEDATA  (XARWARNING_LEVEL+5L) /* file without informationheader */
#define XARWARN_ARCHIVE_CORRUPT        (XARWARNING_LEVEL+6L) /* archive corrupt */
#define XARWARN_FILEDATA_WITHOUT_BODY  (XARWARNING_LEVEL+7L) /* fileheader without file */
#define XARWARN_CRC_FAILED             (XARWARNING_LEVEL+8L) /* crc-check failed */

#define XARMAXWARN (XARWARNING_LEVEL+8L) /* Note: this define will change with future versions */

/* Errorrcodes */
#define XARERROR_LEVEL        (1L<<9)
#define XARERR_NO_MEMORY            (XARERROR_LEVEL+1L)  /* No Memory                                                     */
#define XARERR_CANNOT_CREATE        (XARERROR_LEVEL+2L)  /* Cannot create archive                                         */
#define XARERR_CANNOT_OPEN          (XARERROR_LEVEL+3L)  /* Cannot open archive                                           */
#define XARERR_WRITE_ERROR          (XARERROR_LEVEL+4L)  /* Write error                                                   */
#define XARERR_READ_ERROR           (XARERROR_LEVEL+5L)  /* Read error                                                    */
#define XARERR_NO_ARCHIVE           (XARERROR_LEVEL+6L)  /* File specified is no archive supported by xpkarchive.library  */
#define XARERR_INTERNAL_ERROR       (XARERROR_LEVEL+7L)  /* Internal error, should never occur                            */
#define XARERR_INVALID_TAGS         (XARERROR_LEVEL+8L)  /* Incomplete tags                                               */
#define XARERR_FILE_NOT_FOUND       (XARERROR_LEVEL+9L)  /* File not found                                                */
#define XARERR_INVALID_FILEINDEX    (XARERROR_LEVEL+10L) /* The fileindex is out of range                                 */
#define XARERR_CANNOT_EXAMINE       (XARERROR_LEVEL+11L) /* The dos function Examine() failed                             */
#define XARERR_ARCHIVE_CORRUPT      (XARERROR_LEVEL+12L) /* Archive corrupt                                               */
#define XARERR_INVALID_TYPE         (XARERROR_LEVEL+13L) /* Invalid type of the archive                                   */
#define XARERR_UNKNOWN_TYPE XARERR_INVALID_TYPE          /* or unknown archivetype                                        */
#define XARERR_SAME_SRC_AND_DST     (XARERROR_LEVEL+14L) /* The source and destination archive is the same                */
#define XARERR_DIFFERENT_TYPES      (XARERROR_LEVEL+15L) /* The types of the source and destination archive is different  */
#define XARERR_ABORTED              (XARERROR_LEVEL+16L) /* Operation was aborted by the user                             */
#define XARERR_INPUT_NOT_SUPPORTED  (XARERROR_LEVEL+17L)
#define XARERR_OUTPUT_NOT_SUPPORTED (XARERROR_LEVEL+18L)
#define XARERR_SMALL_BUF            (XARERROR_LEVEL+19L)
#define XARERR_OPERATION_NOT_SUPPORTED (XARERROR_LEVEL+20L)
#define XARERR_NO_METHOD            (XARERROR_LEVEL+21L)
#define XARERR_WRONG_METHOD         (XARERROR_LEVEL+22L)
#define XARERR_WRONG_OS_VERSION     (XARERROR_LEVEL+23L)
#define XARERR_CANNOT_RENAME        (XARERROR_LEVEL+24L)
#define XARERR_MASTERLIB_TOO_OLD    (XARERROR_LEVEL+25L)
#define XARERR_NO_XPK_ARCHIVE       (XARERROR_LEVEL+26L)
#define XARERR_CANNOT_CREATE_FILE   (XARERROR_LEVEL+27L)

#define XARMAXERR (XARERROR_LEVEL+27L) /* NOTE: this define will change with future versions !!! */

/* Errorcodes for sublibraries */
#define XARCUSTOM_LEVEL       (1L<<10)


#ifndef LIBRARIES_XAR_PRIVATE_H

#ifndef NO_XAR_PROTO

XarHandle *XarOpenArchiveA(struct TagItem *);
XarHandle *XarOpenArchive(ULONG,...);
XarLock   *XarGetLock(XarHandle *);
XarLock   *XarNextLock(XarLock *);
XarLock   *XarGetPrevLock(XarLock *);
XarLock   *XarFindFileA(struct TagItem *);
XarLock   *XarFindFile(ULONG,...);
XarLock   *XarCopyFileA(struct TagItem *);
XarLock   *XarCopyFile(ULONG,...);

LONG XarCloseArchive(XarHandle *);
LONG XarSetGenerationA(struct TagItem *);
LONG XarSetGeneration(ULONG,...);
LONG XarModifyFileDataA(struct TagItem *);
LONG XarModifyFileData(ULONG,...);
LONG XarNextGenerationA(struct TagItem *);
LONG XarNextGeneration(ULONG,...);
LONG XarRenameFileA(struct TagItem *);
LONG XarRenameFile(ULONG,...);
LONG XarSetFileNoteA(struct TagItem *);
LONG XarSetFileNote(ULONG,...);

XarLock  * XarAddFileA(struct TagItem *);
XarLock  * XarAddFile(ULONG,...);
LONG  XarExtractFileA(struct TagItem *);
LONG  XarExtractFile(ULONG,...);

struct XarType *XarGetType(XarHandle *);
UBYTE  *XarGetFileName(XarLock *);
UBYTE  *XarGetFileNote(XarLock *);
ULONG   XarGetFileSize(XarLock *);
ULONG   XarGetFileIndex(XarLock *);
UBYTE  XarIsXpkArchive(XarHandle *);

struct XarFileData  *XarGetFileData(XarLock *);
LONG  XarExamine(XarLock *,struct XpkFib *);

void XarUpdateArchivers(void);
LONG XarQueryA(struct TagItem *);
LONG XarQuery(ULONG,...);

LONG XarPackArchive(XarHandle *from, XarHandle *to);

LONG XarProgress(long type, struct XarSubIO *xio, struct XarProgress *xprog, long upos, long cpos);

LONG XarDeleteFile(XarLock *lock);
LONG XarUndeleteFile(XarLock *lock);
UBYTE *XarWhy(XarHandle *,LONG);
LONG XarDirect(XarHandle *,UBYTE *);
LONG XarGetPackMode(XarLock *,struct XarPackMode *);

#endif /* NO_XAR_PROTOS */

#ifndef NO_XAR_PRAGMAS
#pragma libcall XpkArchiveBase XarAddFileA 1E 801
#pragma libcall XpkArchiveBase XarCloseArchive 24 801
#pragma libcall XpkArchiveBase XarCopyFileA 2A 801
#pragma libcall XpkArchiveBase XarExamine 30 9802
#pragma libcall XpkArchiveBase XarExtractFileA 36 801
#pragma libcall XpkArchiveBase XarFindFileA 3C 801
#pragma libcall XpkArchiveBase XarGetFileData 42 801
#pragma libcall XpkArchiveBase XarGetFileIndex 48 801
#pragma libcall XpkArchiveBase XarGetFileName 4E 801
#pragma libcall XpkArchiveBase XarGetFileNote 54 801
#pragma libcall XpkArchiveBase XarGetFileSize 5A 801
#pragma libcall XpkArchiveBase XarGetLock 60 801
#pragma libcall XpkArchiveBase XarGetType 66 801
#pragma libcall XpkArchiveBase XarIsXpkArchive 6C 801
#pragma libcall XpkArchiveBase XarModifyFileDataA 72 801
#pragma libcall XpkArchiveBase XarNextGenerationA 78 801
#pragma libcall XpkArchiveBase XarNextLock 7E 801
#pragma libcall XpkArchiveBase XarOpenArchiveA 84 801
#pragma libcall XpkArchiveBase XarPrevLock 8A 801
#pragma libcall XpkArchiveBase XarRenameFileA 90 801
#pragma libcall XpkArchiveBase XarSetFileNoteA 96 801

/**/
/* Functions for version 2.0+*/
/**/

#pragma libcall XpkArchiveBase XarDeleteFile 9c 801
#pragma libcall XpkArchiveBase XarPackArchive a2 9802
#pragma libcall XpkArchiveBase XarProgress a8 2198005
#pragma libcall XpkArchiveBase XarQueryA ae 801
#pragma libcall XpkArchiveBase XarDirect b4 9802
#pragma libcall XpkArchiveBase XarUndeleteFile ba 801
#pragma libcall XpkArchiveBase XarUpdateArchivers c0 0
#pragma libcall XpkArchiveBase XarWhy c6 0802
#pragma libcall XpkArchiveBase XarGetPackMode cc 9802

#ifdef __SASC_650
#pragma tagcall XpkArchiveBase XarAddFile 1E 801
#pragma tagcall XpkArchiveBase XarCopyFile 2A 801
#pragma tagcall XpkArchiveBase XarExtractFile 36 801
#pragma tagcall XpkArchiveBase XarFindFile 3C 801
#pragma tagcall XpkArchiveBase XarModifyFileData 72 801
#pragma tagcall XpkArchiveBase XarNextGeneration 78 801 /* obsolete */
#pragma tagcall XpkArchiveBase XarOpenArchive 84 801
#pragma tagcall XpkArchiveBase XarRenameFile 90 801
#pragma tagcall XpkArchiveBase XarSetFileNote 96 801

/**/
/* Functions for version 2.0+*/
/**/
#pragma tagcall XpkArchiveBase XarQuery ae 801

#endif

#endif /* NO_XAR_PRAGMAS */

#endif /* LIBRARIES_XAR_PRIVATE_H */

#endif
