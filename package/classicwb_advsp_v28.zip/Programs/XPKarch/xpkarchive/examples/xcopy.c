#include <stdlib.h>
#include <stdio.h>

#include <libraries/xpkarchive.h>
#include "errortext.h"

struct Library *XpkArchiveBase;

main(int argc,char *argv[])
{
   int a;
   XarHandle *src,*dst;
   LONG Error;

   XpkArchiveBase=OpenLibrary("xpkarctest.library",1);
   if(!XpkArchiveBase) {
      fprintf(stderr,"Cannot open xpkarctest.library\n");
      exit(0);
   }

   if(argc<4) {
      fprintf(stderr,"Usage: %s <src_arc> <dst_arc> <file1>::<out1> [<file2>::<out2> ...]\n",argv[0]);
      goto fail1;
   }

   if(!(src=XarOpenArchive(XAR_ArchiveName,argv[1],
                           XAR_Error,&Error,TAG_DONE))) {
      fprintf(stderr,"Cannot open source archive. Error: %s\n",GetText(Error));
      goto fail1;
   }

   if(!(dst=XarOpenArchive(XAR_ArchiveName,argv[2],
                           XAR_ArchiveMode,XAR_ModeAppend,
                           XAR_Error,&Error,TAG_DONE))) {
      fprintf(stderr,"Cannot open destination archive. Error: %s\n",GetText(Error));
      goto fail2;
   }


   for(a=3;a<argc;a++) {
      char tmp[100],*p;
      int gen=0;
      strcpy(tmp,argv[a]);
      if(p=rindex(tmp,',')) {
         if(sscanf(p+1,"%d",&gen)!=1) {
            fprintf(stderr,"Invalid generation\n");
            break;
         }
         *p=0;
         gen--;
      }
      printf("Generation %d of %s\n",gen+1,tmp);

      XarCopyFile(XAR_Archive,src,XAR_DestArchive,dst,
                  XAR_FileName,tmp,XAR_Generation,gen,
                  XAR_AutoNextGen,0,
                  XAR_Error,&Error,TAG_DONE);

      if(Error>=XARERROR_LEVEL) {
         fprintf(stderr,"Fatal Error: %s\n",GetText(Error));
         break;
      }
   }

   XarCloseArchive(dst);
fail2:
   XarCloseArchive(src);
fail1:
   CloseLibrary(XpkArchiveBase);
   exit(0);

}













