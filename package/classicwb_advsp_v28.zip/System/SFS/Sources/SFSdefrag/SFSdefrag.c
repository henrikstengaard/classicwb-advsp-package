// SFSDefrag.c
// Version: 1.4
//

/****************************************************************************************
 *											*
 * # Version 1.3									*
 *  - Arguments added: WINLEFT,WINTOP,WINWIDTH,WINHEIGHT.	(Jean-Marie COAT)	*
 * # Version 1.4									*
 *  - Arguments added: NOWINDOW,DEFAULTFONT,SHOWRESULT.		(jean-Marie COAT)	*
 *											*
 ****************************************************************************************/

/***
gcc -Os -pipe -fomit-frame-pointer -W -Wall -s SFSdefrag.c -o SFSdefragment -noixemul -msmall-code -fbaserel
;gcc -Os -pipe -fomit-frame-pointer -W -Wall -g SFSdefrag.c -o SFSdefragment -D__AMIGADATE__="`dm:amigadate`" -noixemul -msmall-code -fbaserel
;gcc -Os -pipe -fomit-frame-pointer -W -Wall -s SFSdefrag.c -o SFSdefragment -D__AMIGADATE__="`dm:amigadate`" -noixemul -msmall-code -fbaserel
***/


#include <exec/memory.h>
#include <exec/types.h>
#include <intuition/intuition.h>
#include <intuition/screens.h>
#include <intuition/classes.h>
#include <intuition/classusr.h>
// #include <intuition/imageclass.h>
#include <intuition/gadgetclass.h>
#include <libraries/iffparse.h>
#include <libraries/gadtools.h>
#include <graphics/displayinfo.h>
#include <graphics/gfxbase.h>
#include <graphics/gfx.h>
#include <proto/exec.h>
#include <proto/intuition.h>
#include <proto/gadtools.h>
#include <proto/dos.h>
#include <proto/graphics.h>
#include <proto/diskfont.h>
#include <utility/tagitem.h>


#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>

//---------------------------------

#include <packets.h>
#include <query.h>
#include <stdio.h>

#include <string.h>
#include "defs.h"

#define GD_StopGadget	0
#define GD_DeviceGad	1

// #define GDX_StopGadget	0
// #define GDX_DeviceGad	1

#define   max(a,b)    ((a) > (b) ? (a) : (b))

/* FSDefragment Version string */

const char *VersTag = "\0$VER: SFSdefragment 1.4 (" __COMPILATIONDATE__ ") " COMPILER_STRING  "\r\n";

/* Note to people who wish to use this source:
   -------------------------------------------

   This code was created in just a few hours mainly to help debugging
   the Defragmenter visually.  No great effort has been made to make
   it completely stable or OS conform, so beware.

   There's definitely more work to be done :-) */

struct Screen *Scr = NULL;
APTR VisualInfo = NULL;

struct Window *mywindow = NULL;
struct RastPort *rastport;
UWORD dx=10;
UWORD dy=10;

UWORD uw;      /* UnitWidth */
UWORD uh;      /* UnitHeight */
ULONG ppu;     /* Pixels per Unit */
UWORD uhor;    /* Units horizontally */
UWORD uver;    /* Units vertically */
ULONG units;   /* Total number of Units */
ULONG bpu;     /* Blocks per Unit */
ULONG dw=9900, dh=9600;  /* Defrag window width & height */
ULONG dleft=0, dtop=0;  /*  Defrag window left & top */
ULONG *bitmap;

struct Gadget *StatusGadgets[2];
struct Gadget *StatusGList=NULL;

#ifdef __amigaos4__
struct GadToolsIFace *IGadTools;
#else
struct GfxBase *GfxBase;
struct IntuitionBase *IntuitionBase;
#endif
struct Library *GadToolsBase;
struct TextAttr *Font, Attr;

UWORD FontX, FontY;
UWORD OffX, OffY;
UWORD ScreenBarH;

struct DefragmentStep {
  ULONG id;       // id of the step ("MOVE", "DONE" or 0)
  ULONG length;   // length in longwords (can be 0)
  ULONG data[0];  // size of this array is determined by length.
};

#define MAXSTEPS 1000

ULONG steps[MAXSTEPS+20];

ULONG lastread[(MAXSTEPS+20)/5];
ULONG lastwritten[(MAXSTEPS+20)/5];
ULONG lastblocks[(MAXSTEPS+20)/5];

LONG bmffo(ULONG *bitmap,LONG longs,LONG bitoffset);
LONG bmffz(ULONG *bitmap,LONG longs,LONG bitoffset);
LONG bmset(ULONG *bitmap,LONG longs,LONG bitoffset,LONG bits);
LONG bmclr(ULONG *bitmap,LONG longs,LONG bitoffset,LONG bits);
void render(ULONG block, ULONG blocks, WORD pen);
void recalc(ULONG blocks_total, WORD w, WORD h);
void drawrect(UWORD x, UWORD y, UWORD w, UWORD h, WORD pen);
void initfield(ULONG blocks_total);

//----------

void CloseDownScreen( void );
int SetupScreen( void );
static void ComputeFont( UWORD width, UWORD height );
static UWORD ComputeY( UWORD value );
static UWORD ComputeX( UWORD value );
void cleanup(ULONG err);

STRPTR makeBPToCST(BPTR bPtrStr, STRPTR BufToStore, size_t Max);

static LONG GetLenForText(STRPTR LString, LONG LCurrent, struct TextFont *tf);
BYTE DefaultFont = FALSE;

// long _stack = 8192;	// stack size.

//----------
int __nocommandline=1;

int main() {
  struct RDArgs *readarg;
  UBYTE template[]="DEVICE/A,DEBUG/S,ADDBUFFERS/N,WINLEFT/N,WINTOP/N,WINWIDTH/N,WINHEIGHT/N,NOWINDOW/S,DEFAULTFONT/S,SHOWRESULT/S";
  WORD exit=FALSE;
  ULONG buffers=0;
  char wintitle[150];
  char screentitle[140];

  struct {char *name;
          ULONG debug;
          ULONG *buf;
          ULONG *winleft;
          ULONG *wintop;
          ULONG *winwidth;
          ULONG *winheight;
          ULONG nofragwindow;
	  ULONG defaultfont;
	  ULONG	defragresult;} arglist={NULL,0,&buffers,&dleft,&dtop,&dw,&dh,NULL,NULL,NULL};


	// disable C library <ctrl><c> handling
	signal(SIGINT, SIG_IGN);

	//  Open the various shared libraries that are needed
#ifndef __amigaos4__
	IntuitionBase = (struct IntuitionBase *) OpenLibrary("intuition.library",37);
	GfxBase = (struct GfxBase *) OpenLibrary("graphics.library", 37);
#endif
	GadToolsBase = (struct Library *) OpenLibrary("gadtools.library",37);

#ifdef __amigaos4__
        if (GadToolsBase)
        {
           IGadTools = GetInterface(GadToolsBase, "main", 1, NULL);
        }
	if (!IGadTools)
		cleanup(100);
#else
	if (IntuitionBase==NULL || GfxBase==NULL || GadToolsBase==NULL)
		cleanup(100);
#endif

	if((readarg=ReadArgs(template,(LONG *)&arglist,0))!=0)
		{
		struct MsgPort *msgport;
		struct DosList *dl;
		UBYTE name2[50];
		UBYTE *devname=arglist.name;

		strcpy(name2,devname);

		if(!strchr(name2,':'))
			 strcat(name2,":");
		while(*devname!=0)
			{
			if(*devname==':')
				{
				*devname=0;
				break;
				}
			devname++;
			}

		if(arglist.winleft) dleft = *arglist.winleft;
		if(arglist.wintop) dtop = *arglist.wintop;

		if(arglist.winwidth)
			{
			if(*arglist.winwidth < 50) *arglist.winwidth = 50;
			dw = *arglist.winwidth;
			}

		if(arglist.winheight)
			{
			if(*arglist.winheight < 50) *arglist.winheight = 50;
			dh = *arglist.winheight;
			}

		if(arglist.defaultfont!=NULL)
			{
			DefaultFont = TRUE;
			}

		SetupScreen();

		dl=LockDosList(LDF_DEVICES|LDF_READ);
		if((dl=FindDosEntry(dl, arglist.name, LDF_DEVICES))!=0)
			{
			LONG errorcode;

			msgport=dl->dol_Task;

			makeBPToCST(dl->dol_Name, name2, sizeof(name2) - 1);
			strcat(name2, ":");

			sprintf(wintitle, "SFS defragmentation window (%s Version) - Device: %s", GCC_PLATFORM, name2);
			sprintf(screentitle, "SFS defragmentation (%s Version) - Device: %s", GCC_PLATFORM, name2);

			UnLockDosList(LDF_DEVICES|LDF_READ);

			{
			struct TagItem tags[]={{ASQ_TOTAL_BLOCKS, 0},
				{ASQ_VERSION, 0},
				{TAG_END, 0}};

			if((errorcode=DoPkt(msgport, ACTION_SFS_QUERY, (LONG)&tags, 0, 0, 0, 0))!=DOSFALSE)
				{
				ULONG blocks_total=tags[0].ti_Data;
				ULONG blocks_moved=0;

				if(tags[1].ti_Data >= (1<<16) + 83)
					{
					if((errorcode=DoPkt(msgport, ACTION_SFS_DEFRAGMENT_INIT, 0, 0, 0, 0, 0))!=DOSFALSE)
						{
						if((bitmap=AllocVec(blocks_total / 8 + 32, MEMF_CLEAR))!=0)
							{
							if((errorcode=DoPkt(msgport, ACTION_SFS_READ_BITMAP, (LONG)bitmap, 0, blocks_total, 0, 0))!=DOSFALSE)
								{

								if(arglist.nofragwindow != 0)
									{
									struct NewGadget ng;
									struct Gadget *g;
									UWORD  wleft = dleft, wtop = dtop;
									UWORD  BtHeight=0;
									LONG   FontLenght=0;
									LONG   FontLenghtDrive=0;
									LONG   FontLenghtBtCancel=0;
									LONG   FontLenghtTextDefragLabel=0;
									LONG   Space=0;
									struct TextFont *tf;


									tf = OpenDiskFont(Font);
									Space = FontX;
									FontLenghtBtCancel = GetLenForText("Abort", 0, tf) + (Space * 2);
									FontLenghtTextDefragLabel = GetLenForText("Defragment:", 0, tf) + (Space * 2);
									FontLenghtDrive = GetLenForText(name2, 0, tf) + (Space * 2);

									if ( ! ( g = CreateContext(&StatusGList) ) )
										{
										cleanup(20);
										}

									ng.ng_LeftEdge	  =    OffX + Space;
									ng.ng_TopEdge	  =    OffY + (FontY/2); // ComputeY( 2 );
									ng.ng_Width 	  =    FontLenghtBtCancel;
									ng.ng_Height 	  =    FontY + (FontY/2);
									ng.ng_GadgetText  =    (UBYTE *)"Abort";
									ng.ng_TextAttr	  =    Font;
									ng.ng_GadgetID	  =    GD_StopGadget;
									ng.ng_Flags 	  =    PLACETEXT_IN;
									ng.ng_VisualInfo  =    VisualInfo;

									g = CreateGadget( BUTTON_KIND, g, &ng, GT_Underscore, '_', TAG_DONE );

									StatusGadgets[ 0 ] = g;

									//---------------------------------------------------------------------

									ng.ng_LeftEdge	  =    OffX + Space + FontLenghtBtCancel + FontLenghtTextDefragLabel;
									ng.ng_TopEdge	  =    OffY + (FontY/2);
									ng.ng_Width 	  =    FontLenghtDrive;
									ng.ng_GadgetText  =    (UBYTE *)"Defragment:";
									ng.ng_GadgetID	  =    GD_DeviceGad;
									ng.ng_Flags 	  =    PLACETEXT_LEFT;

									g = CreateGadget( TEXT_KIND, g, &ng, GTTX_Text, name2, GTTX_Border, TRUE, GTTX_Justification, GTJ_CENTER, TAG_DONE );

									StatusGadgets[ 1 ] = g;

									BtHeight = ScreenBarH + ng.ng_TopEdge + (FontY/2) + (Scr->WBorTop + 1) + (Scr->WBorBottom + 1);
									FontLenght =  (ng.ng_LeftEdge + ng.ng_Width) + Space + Scr->WBorRight;
									CloseFont(tf);

									if ( ! g )
										{
										cleanup(20);
										}


									if ( ! ( mywindow=OpenWindowTags(0,
											WA_Left, wleft,
											WA_Top, wtop,
											WA_Width, FontLenght,
											WA_Height, BtHeight,
											WA_SizeGadget, FALSE,
											WA_CloseGadget, TRUE,
											WA_IDCMP, BUTTONIDCMP | IDCMP_CLOSEWINDOW | IDCMP_REFRESHWINDOW | IDCMP_VANILLAKEY,
											WA_Flags, WFLG_DRAGBAR | WFLG_DEPTHGADGET,
											WA_Gadgets, StatusGList,
											WA_Title, (UBYTE *)"SFSDefragment 1.4",
											WA_ScreenTitle, (ULONG) screentitle,
											WA_PubScreen,   Scr,
											WA_Activate, FALSE,
											TAG_DONE)))

										cleanup(20);

									GT_RefreshWindow( mywindow, NULL );
									}
								else
									{
									mywindow=OpenWindowTags(0,
										WA_Left, dleft,
										WA_Top, dtop,
										WA_Width, dw,
										WA_Height,dh,
										WA_MinWidth, 100,
										WA_MinHeight, 100,
										WA_MaxWidth, 10000,
										WA_MaxHeight, 10000,
										WA_SizeGadget, TRUE,
										WA_DepthGadget, TRUE,
										WA_CloseGadget, TRUE,
										WA_DragBar, TRUE,
										WA_Title, (ULONG) wintitle,
										WA_Activate, FALSE,
										WA_GimmeZeroZero, TRUE,
										WA_IDCMP, IDCMP_MOUSEBUTTONS | IDCMP_NEWSIZE | IDCMP_VANILLAKEY | IDCMP_CLOSEWINDOW,
										TAG_DONE);
									}

								if(mywindow!=0)
									{
									BYTE defragmented=FALSE;

									rastport=mywindow->RPort;

									// ChangeWindowBox(mywindow,mywindow->Width/4,mywindow->Height/4,mywindow->Width/2,mywindow->Height/2);
									if(arglist.nofragwindow == NULL)
										{
										initfield(blocks_total);
										}

									if(arglist.buf)
										{
										AddBuffers(name2,*arglist.buf);
										}

									lastread[0]=0;
									lastwritten[0]=0;
									lastblocks[0]=0;

									do {
										struct IntuiMessage *msg;
										UWORD class,code,qualifier;

										if(defragmented==FALSE)
											{
											if((errorcode=DoPkt(msgport, ACTION_SFS_DEFRAGMENT_STEP, (LONG)steps, MAXSTEPS, 0, 0, 0))!=DOSFALSE)
												{
												struct DefragmentStep *ds=(struct DefragmentStep *)steps;
												WORD e;

												if(arglist.nofragwindow == 0)
													{
													e=0;

													while(lastblocks[e]!=0)
														{
														render(lastread[e], lastblocks[e], 0);
														render(lastwritten[e], lastblocks[e], 1);
														e++;
														}
													}

												e=0;

                										while(ds->id!=0)
													{
													if(ds->id==MAKE_ID('M','O','V','E') && ds->length==3)
														{
														if(arglist.nofragwindow == 0)
															{
															render(ds->data[1], ds->data[0], 2);
															render(ds->data[2], ds->data[0], 3);
															}
														bmclr(bitmap, (blocks_total+31)/32, ds->data[2], ds->data[0]);
														bmset(bitmap, (blocks_total+31)/32, ds->data[1], ds->data[0]);

														blocks_moved = (blocks_moved + ds->data[0]);
														if(arglist.debug!=0)
															{
															Printf("Moved %ld blocks from %ld to %ld\n", ds->data[0], ds->data[1], ds->data[2]);
															}
														lastread[e]=ds->data[1];
														lastwritten[e]=ds->data[2];
														lastblocks[e]=ds->data[0];
														e++;
														}
													else if(ds->id==MAKE_ID('D','O','N','E'))
														{
														defragmented=TRUE;
														exit=TRUE;
														break;
														}
													ds=(struct DefragmentStep *)((ULONG *)ds + 2 + ds->length);
													}
												lastblocks[e]=0;
												if(arglist.debug!=0 && e!=0)
													{
													Printf("\n");
													}
												}
											}
										else
											{
											WaitPort(mywindow->UserPort);
											}

										// Check user input
										msg=GT_GetIMsg(mywindow->UserPort);
										while(msg!=0)
											{
											class=msg->Class;
											code=msg->Code;
											qualifier=msg->Qualifier;

											msg=GT_GetIMsg(mywindow->UserPort); // ReplyMsg((struct Message *)msg);
											if(class==IDCMP_CLOSEWINDOW)
												{
												exit=TRUE;
												}
											else if(class==IDCMP_GADGETUP)
												{
												exit=TRUE;
												}

											if(arglist.nofragwindow == 0)
												{
										       		if(class==IDCMP_NEWSIZE)
													{
													initfield(blocks_total);
													}
												}
											// Get the next message
											msg=GT_GetIMsg(mywindow->UserPort);
											}
										} while(exit==FALSE);

										CloseWindow(mywindow);
										mywindow = NULL;

										if (StatusGList != NULL)
											{
											FreeGadgets( StatusGList );
											StatusGList = NULL;
											}

										if(arglist.buf)
											{
											AddBuffers(name2,0-*arglist.buf);
											}
										}
									}
							FreeVec(bitmap);
							}
						}
					if(arglist.defragresult!=NULL)
						{
						printf("SFSdefragment result:\n %ld Blocks moved\n of\n %ld Total blocks\n Percentage: %ld %%\n", blocks_moved, blocks_total, ((blocks_moved * 100) / blocks_total));
						}
					}
				else
					{
					PutStr("Version of SmartFilesystem must be 1.83 or newer.  You're using an older version.\n");
					}
				}
			}
			// Free the visual info, etc.
			CloseDownScreen();
		}
	else
		{
		VPrintf("Couldn't find device '%s:'.\n",&arglist.name);
		UnLockDosList(LDF_DEVICES|LDF_READ);
		}
	FreeArgs(readarg);
	}
    else
	{
	PutStr("Bad args!\nArguments: DEVICE/A,DEBUG/S,ADDBUFFERS/N,WINLEFT/N,WINTOP/N,WINWIDTH/N,WINHEIGHT/N,NOWINDOW/S,DEFAULTFONT/S,SHOWRESULT/S\n");
	}

  cleanup(0);
  return 0;
}



void recalc(ULONG blocks_total, WORD w, WORD h) {
  UBYTE pixw[17]={ 1, 2, 3, 2, 3, 4, 3, 5, 4, 5, 4, 6, 5, 6, 5, 6, 6};
  UBYTE pixh[17]={ 1, 1, 1, 2, 2, 2, 3, 2, 3, 3, 4, 3, 4, 4, 5, 5, 6};
  //               1  2  3  4  6  8  9 10 12 15 16 18 20 24 25 30 36

  WORD i;

  for(i=16; i>=0; i--) {
    uw    = pixw[i];
    uh    = pixh[i];
    ppu   = uw * uh;
    uhor  = w/uw;
    uver  = h/uh;
    units = uhor * uver;
    bpu   = (blocks_total+units-1) / units;

    if(bpu<=1) {
      break;
    }
  }

  if(bpu==0) {
    bpu=1;
  }
}



void render(ULONG block, ULONG blocks, WORD pen) {
  ULONG firstunit=block/bpu;
  ULONG lastunit=(block+blocks-1)/bpu;
  ULONG line, offset;
  ULONG endline, endoffset;
  UWORD i;

  SetAPen(rastport, pen);

  line=firstunit / uhor;
  offset=firstunit % uhor;

  endline=lastunit / uhor;
  endoffset=lastunit % uhor;

  for(;;) {
    if(line==endline) {
      i=uh;

      while(i-->0) {
        Move(rastport, dx + offset * uw, dy + line * uh + i);
        Draw(rastport, dx + endoffset * uw + uw-1, dy + line * uh + i);
      }
      break;
    }
    else {
      i=uh;

      while(i-->0) {
        Move(rastport, dx + offset * uw, dy + line * uh + i);
        Draw(rastport, dx + (uhor * uw) - 1, dy + line * uh + i);
      }
    }

    line++;
    offset=0;
  }
}



WORD bfffo(ULONG data,WORD bitoffset) {
  ULONG bitmask=1<<(31-bitoffset);

  /** Finds first set bit in /data/ starting at /bitoffset/.  This function
      considers the MSB to be the first bit. */

  do {
    if((data & bitmask)!=0) {
      return(bitoffset);
    }
    bitoffset++;
    bitmask>>=1;
  } while(bitmask!=0);

  return(-1);
}



WORD bfffz(ULONG data,WORD bitoffset) {
  ULONG bitmask=1<<(31-bitoffset);

  /** Finds first zero bit in /data/ starting at /bitoffset/.  This function
      considers the MSB to be the first bit. */

  do {
    if((data & bitmask)==0) {
      return(bitoffset);
    }
    bitoffset++;
    bitmask>>=1;
  } while(bitmask!=0);

  return(-1);
}



LONG bmffo(ULONG *bitmap,LONG longs,LONG bitoffset) {
  ULONG *scan=bitmap;
  ULONG longoffset;
  WORD bit;

  /* This function finds the first set bit in a region of memory starting
     with /bitoffset/.  The region of memory is /longs/ longs long.  It
     returns the bitoffset of the first set bit it finds. */

  longoffset=bitoffset>>5;
  longs-=longoffset;
  scan+=longoffset;

  bitoffset=bitoffset & 0x1F;

  if(bitoffset!=0) {
    if((bit=bfffo(*scan,bitoffset))>=0) {
      return(bit+((scan-bitmap)<<5));
    }

    scan++;
    longs--;
  }

  while(longs-->0) {
    if(*scan++!=0) {
      return(bfffo(*--scan,0)+((scan-bitmap)<<5));
    }
  }

  return(-1);
}



LONG bmffz(ULONG *bitmap,LONG longs,LONG bitoffset) {
  ULONG *scan=bitmap;
  ULONG longoffset;
  WORD bit;

  /* This function finds the first unset bit in a region of memory starting
     with /bitoffset/.  The region of memory is /longs/ longs long.  It
     returns the bitoffset of the first unset bit it finds. */

  longoffset=bitoffset>>5;
  longs-=longoffset;
  scan+=longoffset;

  bitoffset=bitoffset & 0x1F;

  if(bitoffset!=0) {
    if((bit=bfffz(*scan,bitoffset))>=0) {
      return(bit+((scan-bitmap)<<5));
    }

    scan++;
    longs--;
  }

  while(longs-->0) {
    if(*scan++!=0xFFFFFFFF) {
      return(bfffz(*--scan,0)+((scan-bitmap)<<5));
    }
  }

  return(-1);
}



ULONG bfset(ULONG data,WORD bitoffset,WORD bits) {
  ULONG mask;

  /** Sets /bits/ bits starting from /bitoffset/ in /data/.
      /bits/ must be between 1 and 32. */

  /* we want a mask which sets /bits/ bits starting from bit 31 */

  mask=~((1<<(32-bits))-1);
  mask>>=bitoffset;

  return(data | mask);
}



ULONG bfclr(ULONG data,WORD bitoffset,WORD bits) {
  ULONG mask;

  /* we want a mask which sets /bits/ bits starting from bit 31 */

  mask=~((1<<(32-bits))-1);
  mask>>=bitoffset;

  return(data & ~mask);
}



LONG bmclr(ULONG *bitmap,LONG longs,LONG bitoffset,LONG bits) {
  ULONG *scan=bitmap;
  ULONG longoffset;
  LONG orgbits=bits;

  /* This function clears /bits/ bits in a region of memory starting
     with /bitoffset/.  The region of memory is /longs/ longs long.  If
     the region of memory is too small to clear /bits/ bits then this
     function exits after having cleared all bits till the end of the
     memory region.  In any case it returns the number of bits which
     were actually cleared. */

  longoffset=bitoffset>>5;
  longs-=longoffset;
  scan+=longoffset;

  bitoffset=bitoffset & 0x1F;

  if(bitoffset!=0) {
    if(bits<32) {
      *scan=bfclr(*scan,bitoffset,bits);
    }
    else {
      *scan=bfclr(*scan,bitoffset,32);
    }

    scan++;
    longs--;
    bits-=32-bitoffset;
  }

  while(bits>0 && longs-->0) {
    if(bits>31) {
      *scan++=0;
    }
    else {
      *scan=bfclr(*scan,0,bits);
    }
    bits-=32;
  }

  if(bits<=0) {
    return(orgbits);
  }
  return(orgbits-bits);
}



LONG bmset(ULONG *bitmap,LONG longs,LONG bitoffset,LONG bits) {
  ULONG *scan=bitmap;
  ULONG longoffset;
  LONG orgbits=bits;

  /* This function sets /bits/ bits in a region of memory starting
     with /bitoffset/.  The region of memory is /longs/ longs long.  If
     the region of memory is too small to set /bits/ bits then this
     function exits after having set all bits till the end of the
     memory region.  In any case it returns the number of bits which
     were actually set. */

  longoffset=bitoffset>>5;
  longs-=longoffset;
  scan+=longoffset;

  bitoffset=bitoffset & 0x1F;

  if(bitoffset!=0) {
    if(bits<32) {
      *scan=bfset(*scan,bitoffset,bits);
    }
    else {
      *scan=bfset(*scan,bitoffset,32);
    }

    scan++;
    longs--;
    bits-=32-bitoffset;
  }

  while(bits>0 && longs-->0) {
    if(bits>31) {
      *scan++=0xFFFFFFFF;
    }
    else {
      *scan=bfset(*scan,0,bits);
    }
    bits-=32;
  }

  if(bits<=0) {
    return(orgbits);
  }
  return(orgbits-bits);
}


void drawrect(UWORD x, UWORD y, UWORD w, UWORD h, WORD pen) {
  SetAPen(rastport, pen);

  Move(rastport, x, y);
  Draw(rastport, x, y+h-1);
  Draw(rastport, x+w-1, y+h-1);
  Draw(rastport, x+w-1, y);
  Draw(rastport, x, y);
}


void drawbox(UWORD x, UWORD y, UWORD w, UWORD h, WORD pen) {
  SetAPen(rastport, pen);
  RectFill(rastport, x, y, x+w-1, y+h-1);
}



void initfield(ULONG blocks_total) {
  ULONG start,end, endvalue = -1;
  ULONG current=0;
  UWORD fieldw, fieldh;

  drawbox(0, 0, mywindow->GZZWidth, mywindow->GZZHeight, 0);

  dw=mywindow->GZZWidth-20;
  dh=mywindow->GZZHeight-20;

  recalc(blocks_total, dw, dh);

  fieldw=uhor*uw;
  fieldh=(((blocks_total+bpu-1) / bpu + uhor-1) / uhor) * uh;

  drawrect(dx-3, dy-3, fieldw+6, fieldh+6, -1);
  drawrect(dx-2, dy-2, fieldw+4, fieldh+4, -1);

  // printf("%ld pixel = %ld blocks\n", uh*uw, bpu);

  while(current<blocks_total) {
    start=bmffz(bitmap, (blocks_total+31)/32, current);
    end=bmffo(bitmap, (blocks_total+31)/32, start);

    // if(end==-1)
    if(end == endvalue) {
      end=blocks_total;
    }

    render(start, end-start, 1);
    current=end;
  }
}
//-----------------------------------------------------------------------------

static UWORD ComputeX( UWORD value )
{
	return(( UWORD )(( FontX * value ) / 8 ));
}

//-----------------------------------------------------------------------------

static UWORD ComputeY( UWORD value )
{
	return(( UWORD )(( FontY * value ) / 8 ));
}

//-----------------------------------------------------------------------------

static void ComputeFont( UWORD width, UWORD height )
{
	struct TextFont *tf;
	Font = &Attr;

	Font->ta_Name = Scr->Font->ta_Name;
	tf = OpenDiskFont(Scr->Font);
	ScreenBarH = tf->tf_YSize + Scr->WBorTop + 1;
	OffY  = ScreenBarH;
	CloseFont(tf);

	if (DefaultFont == TRUE)
		{
		// Default font.
		Font->ta_Name = ((struct GfxBase *)GfxBase)->DefaultFont->tf_Message.mn_Node.ln_Name;
		Font->ta_YSize = FontY = ((struct GfxBase *)GfxBase)->DefaultFont->tf_YSize;
		FontX = ((struct GfxBase *)GfxBase)->DefaultFont->tf_XSize;
		}
	else
		{
		tf = OpenDiskFont(Scr->Font);
		Font->ta_YSize = FontY = tf->tf_YSize;
		FontX = tf->tf_XSize;
		Font = Scr->Font;
		CloseFont(tf);
		}

	OffX = Scr->WBorLeft;


	if ( width && height )
		{
		if (( ComputeX( width ) + OffX + Scr->WBorRight ) > Scr->Width )
			goto UseTopaz;
		if (( ComputeY( height ) + OffY + Scr->WBorBottom ) > Scr->Height )
			goto UseTopaz;
		}

	return;

UseTopaz:
	Font->ta_Name = (STRPTR)"topaz.font";
	FontX = FontY = Font->ta_YSize = 8;
}

//-----------------------------------------------------------------------------

int SetupScreen( void )
{
	if ( ! ( Scr = LockPubScreen( NULL )))
		return( 1L );

	ComputeFont( 0L, 0L );

	if ( ! ( VisualInfo = GetVisualInfo( Scr, TAG_DONE )))
		return( 2L );

    return( 0L );
}

//-----------------------------------------------------------------------------

void CloseDownScreen( void )
{
	if (VisualInfo)
		{
		FreeVisualInfo( VisualInfo );
		VisualInfo = NULL;
		}

	if (Scr)
		{
		UnlockPubScreen( NULL, Scr );
		Scr = NULL;
		}
}

//-----------------------------------------------------------------------------

void cleanup(ULONG outerr)
{

#ifdef __amigaos4__
	if (IGadTools)
	{
		DropInterface((struct Interface *)IGadTools);
	}
#else
	if (IntuitionBase!=NULL)
		{
		CloseLibrary((struct Library *)IntuitionBase);
		IntuitionBase=NULL;
		}

	if (GfxBase!=NULL)
		{
		CloseLibrary((struct Library *)GfxBase);
		GfxBase = NULL;
		}
#endif

	if (GadToolsBase!=NULL)
		{
		CloseLibrary(GadToolsBase);
		GadToolsBase = NULL;
		}

	exit(outerr);
}

//-----------------------------------------------------------------------------

STRPTR makeBPToCST(BPTR bPtrStr, STRPTR BufToStore, size_t Max)
{
	UBYTE *bStrAdd = BADDR(bPtrStr);
	size_t Length = bStrAdd[0];

	if (Length >= Max)
		Length = Max - 1;

	memcpy(BufToStore, bStrAdd + 1, Length);
	BufToStore[Length] = '\0';

	return BufToStore;
}

//-----------------------------------------------------------------------------

static LONG GetLenForText(STRPTR LString, LONG LCurrent, struct TextFont *tf)
{
	LONG	PixeLs;
	struct RastPort rast;

	InitRastPort(&rast);
	SetFont(&rast, tf);

	PixeLs = TextLength(&rast, (STRPTR) LString, strlen(LString));

	if (PixeLs > LCurrent)
		LCurrent = PixeLs;

	return LCurrent;
}

