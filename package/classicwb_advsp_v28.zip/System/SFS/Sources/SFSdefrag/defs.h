/*
 * defs.h
 *
 * Compiler definitions
 *
 */

#ifndef  DEFS_H
#define  DEFS_H

#ifndef  EXEC_TYPES_H
#include <exec/types.h>
#endif

#define STR(x)  STR2(x)
#define STR2(x) #x

#ifdef __PPC__
#define	GCC_PLATFORM	"PPC"
#else
#define	GCC_PLATFORM	"68K"
#endif
#define	COMPILER_STRING	" (GCC " STR(__GNUC__) "." STR(__GNUC_MINOR__) ".x " GCC_PLATFORM ")"

#endif /* DEFS_H */

